/***********************************************************************
 * Copyright (C) 2014, Nanjing TunPeer, Inc. 
 * Description:     CSimpleMessageQueue.h
 * Others:
 * Version:          V1.0
 * Author:           XiangRui Yang
 * Date:             2018-6-22
 *
 * History 1:
 *     Date:          
 *     Version:       
 *     Author:       
 *     Modification: 
**********************************************************************/

#ifndef CSIMPLEMESSAGEQUEUE_H
#define CSIMPLEMESSAGEQUEUE_H
#include "starbase/CAWDefines.h"
#include "starbase/CAWString.h"
#include "starbase/CAWTimerWrapperID.h"
#include "starbase/CAWTimeValue.h"
#include "starbase/CAWError.h"
#include "starbase/CAWConditionVariable.h"
#include <list>
class CAW_OS_EXPORT CAWSimpleMessage
{
public:
    CAWSimpleMessage(uint32_t xid, const char *pmsg, size_t msgsize, void *cookie);
    ~CAWSimpleMessage();
    uint32_t GetXid(){return m_xid;}
    void * GetCooKie(){return m_cookie;}
    char * GetMsg(){return m_pmsg;}
    size_t GetMsgSize(){return m_nmsgsize;}
    size_t GetCount(){return m_sendcount;}
    void SendCoutPlus(){m_sendcount += 1;};
private:
    uint32_t m_xid;
    char *m_pmsg;
    size_t m_nmsgsize;
    void *m_cookie;
    uint32_t m_sendcount;
};


class CAW_OS_EXPORT CAWSimpleMessageQueueSink 
{
public:
    virtual ~CAWSimpleMessageQueueSink(){}
    virtual void OnSendRequest(void *cookie, const char *msg, size_t msgsize)=0;
};

class CAW_OS_EXPORT CAWSimpleMessageQueue : public CAWTimerWrapperIDSink
{
public:
    CAWSimpleMessageQueue();
    ~CAWSimpleMessageQueue();
    CAWResult Init(CAWSimpleMessageQueueSink *psink);
public:
    virtual void OnTimer(CAWTimerWrapperID* aId);
public:
    CAWResult PostRequest(uint32_t xid, const char *pmsg, size_t msgsize, void *cookie);
    CAWResult RcvResponse(uint32_t xid);
private:
    CAWMutexThread m_Mutex;
    CAWTimerWrapperID m_timerout;
    std::list<CAWSimpleMessage *> m_msgqueue;
    CAWSimpleMessageQueueSink *m_psink;
};


#endif//CSIMPLEMESSAGEQUEUE_H
