/***********************************************************************
 * Copyright (C) 2013, Nanjing WFN Technology Co., Ltd 
 * Description: 
 * Others:
 * Version:          V1.0
 * Author:           Yi Jian
 * Date:             2013-09-12
 *
 * History 1:
 *     Date:          
 *     Version:       
 *     Author:       
 *     Modification: 
**********************************************************************/

#ifndef CMPIPE_H
#define CMPIPE_H

#define CAW_DEFAULT_MAX_SOCKET_BUFSIZ 65535

class CAWPipe  
{
public:
	CAWPipe();
	~CAWPipe();

	CAWResult Open(DWORD aSize = CAW_DEFAULT_MAX_SOCKET_BUFSIZ);
	CAWResult Close();

	CAW_HANDLE GetReadHandle() const;
	CAW_HANDLE GetWriteHandle() const;

private:
	CAW_HANDLE m_Handles[2];
};

#endif // !CMPIPE_H
