#ifndef CAWWFACE_H
#define CAWWFACE_H
#include "starbase/CAWStarBase.h"
#include "wface/CAWConnectionInterface.h"
#include "wface/CAWErrorNetwork.h"
#endif//CAWWFACE_H