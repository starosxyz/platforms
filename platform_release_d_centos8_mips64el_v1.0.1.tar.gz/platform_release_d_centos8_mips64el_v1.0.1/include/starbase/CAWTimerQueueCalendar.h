/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/

#ifndef CAWTIMERQUEUECALENDAR_H
#define CAWTIMERQUEUECALENDAR_H

#include "starbase/CAWStdCpp.h"
#include "starbase/CAWThreadInterface.h"
#include "starbase/CAWUtilClasses.h"
#include <map>
#include "starbase/CAWTimeValue.h"

class IAWEventQueue;

template <class ValueType>
struct CAW_OS_EXPORT CAWTimerQueueCalendarSlotT
{
    CAWTimerQueueCalendarSlotT *m_pNext;
    ValueType m_Value;
};

/// Implement calendar timer. 
/// The timer callback is not precision, it's decided by <aSlotInterval>.
class CAW_OS_EXPORT CAWTimerQueueCalendar : public IAWTimerQueue, public IAWEvent
{
public:
    // <aSlotInterval> is the time value in ms of one slot,
    // <aMaxTime> is total time value in ms of all slots.
    // <aEq>  is used to notify when <aInterval> of ScheduleTimer() equals 0.
    CAWTimerQueueCalendar(
                    DWORD aSlotInterval, 
                    DWORD aMaxTime, 
                    IAWEventQueue *aEq);

    virtual ~CAWTimerQueueCalendar();

    // interface IAWTimerQueue
    virtual CAWResult ScheduleTimer(IAWTimerHandler *aEh, 
                    LPVOID aToken, 
                    const CAWTimeValue &aInterval,
                    DWORD aCount);

    virtual CAWResult CancelTimer(IAWTimerHandler *aEh);

    // interface IAWEvent
    // <aInterval> of ScheduleTimer() equals 0.
    virtual CAWResult OnEventFire();
    virtual void OnDestorySelf();

    // timer tick every <aSlotInterval>.
    void TimerTick();

private:
    typedef IAWTimerHandler* HandlerType;
    struct ValueType
    {
        ValueType(HandlerType aEh, LPVOID aToken, 
        const CAWTimeValue &aInterval, DWORD aCount) 
        : m_pHanler(aEh), m_pToken(aToken)
        , m_tvInterval(aInterval), m_dwCount(aCount) 
        { }

        bool operator == (const ValueType &aRight) const
        {
            return m_pHanler == aRight.m_pHanler;
        }

        HandlerType m_pHanler;
        LPVOID m_pToken;
        CAWTimeValue m_tvInterval;
        DWORD m_dwCount;
    } ;

    typedef CAWTimerQueueCalendarSlotT<ValueType> SlotType;
    typedef std::allocator<SlotType> AllocType;
    typedef std::map<HandlerType, DWORD> HanlersType;

private:
    SlotType* NewSlot_i(const ValueType &aValue)
    {
        SlotType *pNew = m_Alloc.allocate(1, NULL);
        if (pNew) {
            pNew->m_pNext = NULL;
            new (&pNew->m_Value) ValueType(aValue);
        }
        return pNew;
    }

    void DeleteSlot_i(SlotType *aSlot)
    {
        aSlot->m_Value.~ValueType();
        m_Alloc.deallocate(aSlot, 1);
    }

    SlotType* RemoveUniqueHandler_i(const HandlerType &aHanler);
    SlotType* RemoveUniqueSlot_i(
                    SlotType *&aFirst, 
                    const HandlerType &aHanler);

    void InsertUnique_i(const CAWTimeValue &aInterval, SlotType *aInsert);

public:
    CAWEnsureSingleThread m_Est;

private:
    DWORD m_dwInterval;
    SlotType **m_ppSlots;
    DWORD m_dwMaxSlotNumber;
    DWORD m_dwCurrentSlot;
    AllocType m_Alloc;
    IAWEventQueue *m_pEventQueue;
    SlotType *m_pEventSlot;
    HanlersType m_Hanlers;
};

#endif // !CAWTIMERQUEUECALENDAR_H

