/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWUTILS_H
#define CAWUTILS_H
#include "starbase/CAWDefines.h"
#include "starbase/CAWString.h"
#include <chrono>
#include <ctime>
#include <vector>
inline void SplitString(const CAWString& s, std::vector<char *>& v, const CAWString& c)
{
    char *p=NULL; 
    p = strtok((char *)s.c_str(), c.c_str());
    while(p)  
    {   
        v.push_back(p);
        p = strtok(NULL, c.c_str());     
    }
}


CAW_OS_EXPORT CAWString GetProcessName();
CAW_OS_EXPORT CAWString GetBinHomePath();
CAW_OS_EXPORT void BufferStringCopy(char *buffer, size_t buffersize, const CAWString &fromstr);
CAW_OS_EXPORT void BufferStringCopy(char *buffer, size_t buffersize, const char *modestring);

CAW_OS_EXPORT CAWResult StrToU64(const CAWString &str, uint64_t &valuep);
CAW_OS_EXPORT CAWResult StrToU32(const CAWString &str, uint32_t &valuep);
CAW_OS_EXPORT CAWResult StrTo64(const CAWString &str, int64_t &valuep);
CAW_OS_EXPORT CAWResult StrTo32(const CAWString &str, int32_t &valuep);

CAW_OS_EXPORT CAWString U32ToStr(uint32_t valuep);
CAW_OS_EXPORT CAWString U64ToStr(uint64_t valuep);
CAW_OS_EXPORT CAWString RandString(char *buffer,const int buffersize);

CAW_OS_EXPORT long GetCurrentTimerInMSec();


CAW_OS_EXPORT CAWResult GetProcessIDByName(const char* pName, CAW_PID &pid);
CAW_OS_EXPORT std::time_t getCurrentTime();
CAW_OS_EXPORT CAWResult ResolveStringEnv(const CAWString& strSrc, CAWString& strResult);

CAW_OS_EXPORT void memory_cleanse(void *ptr, size_t len);
#endif//CAWUTILS_H

