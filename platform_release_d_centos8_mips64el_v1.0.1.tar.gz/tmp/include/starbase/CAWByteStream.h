/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWBYTESTREAM_H
#define CAWBYTESTREAM_H

#include "starbase/CAWDebug.h"
template <class BlockType, class ConvertorType>
class CAW_OS_EXPORT CAWByteStreamT
{
    enum { STRING_LEN_MAX = 32767 };
public:
    CAWByteStreamT(BlockType &aBlock)
        : m_Block(aBlock)
        , m_ResultRead(CAW_OK)
        , m_ResultWrite(CAW_OK)
    {
    }

    CAWByteStreamT& operator<<(char c)
    {
        Write(&c, sizeof(char));
        return *this;
    }

    CAWByteStreamT& operator<<(unsigned char c)
    {
        Write(&c, sizeof(unsigned char));
        return *this;
    }

    CAWByteStreamT& operator<<(short n)
    {
        return *this << (unsigned short)n;
    }

    CAWByteStreamT& operator<<(unsigned short n)
    {
        ConvertorType::Swap(n);
        Write(&n, sizeof(unsigned short));
        return *this;
    }

    CAWByteStreamT& operator<<(int n)
    {
        return *this << (unsigned int)n;
    }

    CAWByteStreamT& operator<<(unsigned int n)
    {
        ConvertorType::Swap(n);
        Write(&n, sizeof(unsigned int));
        return *this;
    }

    CAWByteStreamT& operator<<(long n)
    {
        return *this << (unsigned long)n;
    }

    CAWByteStreamT& operator<<(unsigned long n)
    {
        ConvertorType::Swap(n);
        Write(&n, sizeof(unsigned long));
        return *this;
    }


    CAWByteStreamT& operator<<(long long n)
    {
        return *this << (unsigned long long)n;
    }

    CAWByteStreamT& operator<<(unsigned long long n)
    {
        ConvertorType::Swap(n);
        Write(&n, sizeof(unsigned long long));
        return *this;
    }

    

    CAWByteStreamT& operator<<(float n)
    {
        ConvertorType::Swap(n);
        Write(&n, sizeof(float));
        return *this;
    }

    CAWByteStreamT& operator<<(double n)
    {
        ConvertorType::Swap(n);
        Write(&n, sizeof(double));
        return *this;
    }

    CAWByteStreamT& operator<<(const CAWString &str)
    {
        return WriteString(str.c_str(), str.length());
    }
    CAWByteStreamT& operator<<(const std::string &str)
    {
        return WriteString(str.c_str(), str.length());
    }

    CAWByteStreamT& operator<<(const char *str)
    {
        size_t len = 0;
        if (str)
        {
            len = strlen(str);
        }
        return WriteString(str, len);
    }

    CAWByteStreamT& WriteString(const char *str, size_t ll)
    {
        unsigned short len = static_cast<unsigned short>(ll);
        CAW_ASSERTE(len < STRING_LEN_MAX);
        if (len >= STRING_LEN_MAX) {
            CAW_ERROR_TRACE_THIS("CAWByteStreamT::WriteString, too long, len=" << len);
            m_ResultWrite = CAW_ERROR_UNEXPECTED;
            return *this;
        }

        (*this) << len;
        if (len > 0)
            Write(str, len);
        return *this;
    }

    CAWByteStreamT& WriteStringWith4BytesLength(const CAWString &str)
    {
        return WriteStringWith4BytesLength(str.c_str(), str.length());
    }

    CAWByteStreamT& WriteStringWith4BytesLength(const char *str, unsigned long ll)
    {
        (*this) << ll;
        if (ll > 0)
            Write(str, ll);
        return *this;
    }

    CAWByteStreamT& operator>>(char& c)
    {
        Read(&c, sizeof(char));
        return *this;
    }

    CAWByteStreamT& operator>>(unsigned char& c)
    {
        Read(&c, sizeof(unsigned char));
        return *this;
    }

    CAWByteStreamT& operator>>(unsigned short& n)
    {
        Read(&n, sizeof(unsigned short));
        ConvertorType::Swap(n);
        return *this;
    }

    CAWByteStreamT& operator>>(short& n)
    {
        return *this >> (unsigned short&)n;
    }

    CAWByteStreamT& operator>>(int& n)
    {
        return *this >> (unsigned int&)n;
    }

    CAWByteStreamT& operator>>(unsigned int& n)
    {
        Read(&n, sizeof(unsigned int));
        ConvertorType::Swap(n);
        return *this;

    }

    CAWByteStreamT& operator>>(long& n)
    {
        return *this >> (unsigned long&)n;
    }

    CAWByteStreamT& operator>>(unsigned long& n)
    {
        Read(&n, sizeof(unsigned long));
        ConvertorType::Swap(n);
        return *this;
    }

    CAWByteStreamT& operator>>(long long& n)
    {
        return *this >> (unsigned long long&)n;
    }

    CAWByteStreamT& operator>>(unsigned long long& n)
    {
        Read(&n, sizeof(unsigned long long));
        ConvertorType::Swap(n);
        return *this;
    }


    CAWByteStreamT& operator>>(float& n)
    {
        Read(&n, sizeof(float));
        ConvertorType::Swap(n);
        return *this;
    }

    CAWByteStreamT& operator>>(double& n)
    {
        Read(&n, sizeof(double));
        ConvertorType::Swap(n);
        return *this;
    }

    CAWByteStreamT& operator>>(CAWString& str)
    {
        unsigned short len = 0;
        (*this) >> len;
        CAW_ASSERTE(len < STRING_LEN_MAX);
        if (len >= STRING_LEN_MAX) {
            CAW_ERROR_TRACE_THIS("CAWByteStreamT::operator>>CAWString, too long, len=" << len);
            m_ResultRead = CAW_ERROR_UNEXPECTED;
            return *this;
        }

        if (len > 0) {
            str.resize(0);
            str.resize(len);
            Read(const_cast<char*>(str.c_str()), len);
        }
        return *this;
    }
    CAWByteStreamT& operator>>(std::string& str)
    {
        unsigned short len = 0;
        (*this) >> len;
        CAW_ASSERTE(len < STRING_LEN_MAX);
        if (len >= STRING_LEN_MAX) {
            CAW_ERROR_TRACE_THIS("CAWByteStreamT::operator>>CAWString, too long, len=" << len);
            m_ResultRead = CAW_ERROR_UNEXPECTED;
            return *this;
        }

        if (len > 0) {
            str.resize(0);
            str.resize(len);
            Read(const_cast<char*>(str.c_str()), len);
        }
        return *this;
    }

    CAWByteStreamT& ReadStringWith4BytesLength(CAWString& str)
    {
        unsigned long len = 0;
        (*this) >> len;

        if (len > 0) {
            str.resize(0);
            str.resize(len);
            Read(const_cast<char*>(str.c_str()), len);
        }
        return *this;
    }

    CAWByteStreamT& PreRead(void *aDst, unsigned int aCount)
    {
        if (CAW_SUCCEEDED(m_ResultRead)) {
            size_t ulRead = 0;
            m_ResultRead = m_Block.Read(aDst, aCount, &ulRead, FALSE);
#ifdef CAW_DEBUG
            if (CAW_SUCCEEDED(m_ResultRead))
            {
                CAW_ASSERTE(ulRead == aCount);
            }
#endif // CAW_DEBUG
        }
        if (CAW_FAILED(m_ResultRead)) {
            CAW_ERROR_TRACE_THIS("CAWByteStreamT::PreRead, can't read. m_ResultRead=" << m_ResultRead);
        }
        return *this;
    }

    CAWByteStreamT& Read(void *aDst, size_t aCount)
    {
        if (CAW_SUCCEEDED(m_ResultRead)) {
            size_t ulRead = 0;
            m_ResultRead = m_Block.Read(aDst, aCount, &ulRead);
#ifdef CAW_DEBUG
            if (CAW_SUCCEEDED(m_ResultRead))
            {
                CAW_ASSERTE(ulRead == aCount);
            }
#endif // CAW_DEBUG
        }
        if (CAW_FAILED(m_ResultRead)) {
            CAW_ERROR_TRACE_THIS("CAWByteStreamT::Read, can't read. m_ResultRead=" << m_ResultRead);
        }
        return *this;
    }

        CAWByteStreamT& Write(const void *aDst, size_t aCount)
        {
            if (CAW_SUCCEEDED(m_ResultWrite)) {
                size_t ulWritten = 0;
                m_ResultWrite = m_Block.Write(aDst, aCount, &ulWritten);
#ifdef CAW_DEBUG
                if (CAW_SUCCEEDED(m_ResultWrite))
                {
                    CAW_ASSERTE(ulWritten == aCount);
                }
#endif // CAW_DEBUG
            }
            if (CAW_FAILED(m_ResultWrite)) {
                CAW_ERROR_TRACE_THIS("CAWByteStreamT::Write, can't write. m_ResultWrite=" << m_ResultWrite);
            }
            return *this;
        }
        size_t GetChainedLength() const 
        {
            return m_Block.GetChainedLength();
        }
        size_t GetChainedCapacity() const
        {
            return m_Block.GetChainedCapacity();
        }

    BOOL IsGood()
    {
        if (CAW_SUCCEEDED(m_ResultWrite) && CAW_SUCCEEDED(m_ResultRead))
            return TRUE;
        else
            return FALSE;
    }

private:
    BlockType &m_Block;
    CAWResult m_ResultRead;
    CAWResult m_ResultWrite;

    // Not support bool because its sizeof is not fixed.
    CAWByteStreamT& operator<<(bool n);
    CAWByteStreamT& operator>>(bool& n);

    // Not support long double.
    CAWByteStreamT& operator<<(long double n);
    CAWByteStreamT& operator>>(long double& n);
};

class CAW_OS_EXPORT CAWHostNetworkConvertorNormal
{
public:
    static void Swap(unsigned long long &aHostLongLong)
    {
#ifdef CAW_LITTLE_ENDIAN
        Swap8(&aHostLongLong, &aHostLongLong);
#endif // CAW_LITTLE_ENDIAN
    }

    static void Swap(unsigned long &aHostLong)
    {

#ifdef CAW_LITTLE_ENDIAN
#if defined(CAW_ARCH_64_BITS)
        Swap8(&aHostLong, &aHostLong);
#else
        Swap4(&aHostLong, &aHostLong);
#endif

#endif // CAW_LITTLE_ENDIAN
    }
    
    static void Swap(unsigned int &aHostLong)
    {
#ifdef CAW_LITTLE_ENDIAN
        Swap4(&aHostLong, &aHostLong);
#endif // CAW_LITTLE_ENDIAN
    }

    static void Swap(unsigned short &aHostShort)
    {
#ifdef CAW_LITTLE_ENDIAN
        Swap2(&aHostShort, &aHostShort);
#endif // CAW_LITTLE_ENDIAN
    }

    static void Swap(float &aHostFloat)
    {
#ifdef CAW_LITTLE_ENDIAN
        Swap4(&aHostFloat, &aHostFloat);
#endif // CAW_LITTLE_ENDIAN
    }

    static void Swap(double &aHostDouble)
    {
#ifdef CAW_LITTLE_ENDIAN
        Swap8(&aHostDouble, &aHostDouble);
#endif // CAW_LITTLE_ENDIAN
    }

    // mainly copied from ACE_CDR
    static void Swap2(const void *orig, void* target)
    {
        register unsigned short usrc = 
            * reinterpret_cast<const unsigned short*>(orig);
        register unsigned short* udst = 
            reinterpret_cast<unsigned short*>(target);
        *udst = (usrc << 8) | (usrc >> 8);
    }

    static void Swap4(const void* orig, void* target)
    {
        register unsigned int x = 
            * reinterpret_cast<const unsigned int*>(orig);
        x = (x << 24) | ((x & 0xff00) << 8) | ((x & 0xff0000) >> 8) | (x >> 24);
            * reinterpret_cast<unsigned int*>(target) = x;
    }

    static void Swap8(const void* orig, void* target)
    {
        register unsigned int x = *reinterpret_cast<const unsigned int *>(orig);
        register unsigned int y = *reinterpret_cast<const unsigned int *>(static_cast<const char*>(orig) + 4);
        x = (x << 24) | ((x & 0xff00) << 8) | ((x & 0xff0000) >> 8) | (x >> 24);
        y = (y << 24) | ((y & 0xff00) << 8) | ((y & 0xff0000) >> 8) | (y >> 24);
        * reinterpret_cast<unsigned int *>(target) = y;
        * reinterpret_cast<unsigned int *>(static_cast<char*>(target) + 4) = x;
    }
};

class CAW_OS_EXPORT CAWHostNetworkConvertorNull
{
public:
    static void Swap(unsigned long &aHostLong)
    {
        CAW_UNUSED_ARG(aHostLong);
    }

    static void Swap(unsigned short &aHostShort)
    {
        CAW_UNUSED_ARG(aHostShort);
    }

    static void Swap(float &aHostFloat)
    {
        CAW_UNUSED_ARG(aHostFloat);
    }

    static void Swap(double &aHostDouble)
    {
        CAW_UNUSED_ARG(aHostDouble);
    }

    static void Swap(unsigned long long &aHostLL)
    {
        CAW_UNUSED_ARG(aHostLL);
    }

};

#include "CAWMessageBlock.h"

typedef CAWByteStreamT<CAWMessageBlock, CAWHostNetworkConvertorNormal> CAWByteStreamNetwork;
typedef CAWByteStreamT<CAWMessageBlock, CAWHostNetworkConvertorNull> CAWByteStreamMemory;

#endif // !CMBYTESTREAM_H

