/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/


#ifndef CAWTHREAD_H
#define CAWTHREAD_H

#include "starbase/CAWThreadManager.h"
#include "starbase/CAWAtomicOperationT.h"
#include <vector>
#include <string>
using namespace std;
class IAWEventQueue;
class IAWTimerQueue;
class IAWReactor;
class CAWEventThread;

class CAW_OS_EXPORT CAWThread
{
public:
    CAW_THREAD_ID GetThreadId();
    void SetThreadId(CAW_THREAD_ID id);
    CAWThreadManager::TType GetThreadType();
    CAW_THREAD_HANDLE GetThreadHandle();

    // Create thread.
    // The function won't return until OnThreadInit() returns.
    virtual CAWResult Create(
        CAWThreadManager::TType aType, 
        CAWThreadManager::TFlag aFlag = CAWThreadManager::TF_JOINABLE);

    virtual CAWResult CreateNotRun(
            CAWThreadManager::TType aType, 
            CAWThreadManager::TFlag aFlag = CAWThreadManager::TF_JOINABLE);

    // Stop thread so that let the thread function return.
    virtual CAWResult Stop(CAWTimeValue* aTimeout = NULL);

    virtual CAWResult OnCreate();
    CAWResult BlockSignal();

    // Wait until the thread function return.
    CAWResult Join();

    // Delete this.
    CAWResult Destory(CAWResult aReason);

    virtual void OnThreadInit();
    virtual void OnThreadRun() = 0;

    virtual IAWReactor* GetReactor();
    virtual IAWEventQueue* GetEventQueue();
    virtual IAWTimerQueue* GetTimerQueue();
    CAWString GetCPUSet();
    void SetCPUSet(const CAWString &cpuset);

protected:
    CAWThread();
    virtual ~CAWThread();
private:
#ifdef CAW_WIN32
    static unsigned WINAPI ThreadProc(void *aPara);
#else
    static void* ThreadProc(void *aPara);
#endif // CAW_WIN32
    void SplitString(const string& s, vector<string>& v, const string& c);
protected:
    CAW_THREAD_ID m_Tid;
    CAW_THREAD_HANDLE m_Handle;
    CAWThreadManager::TType m_Type;
    CAWThreadManager::TFlag m_Flag;

private:
    CAWEventThread *m_pEvent4Start;
    BOOL m_bRegistered;
    CAWString m_cpuset;
    CAWAtomicOperation m_NeedDelete;
};

#endif // !CAWTHREAD_H

