#ifndef STRING_JSON_H_INCLUDED
# define STRING_JSON_H_INCLUDED
# include "json_config.h"
# include <vector>
# include <string>
# include <iostream>

/** \brief JSON (JavaScript Object Notation).
 */
namespace Json {
class JSON_API jsonstring
{
public:
    jsonstring();
    jsonstring(const jsonstring& str);
    jsonstring(const jsonstring& str, size_t pos, size_t len = std::string::npos);
    jsonstring(const char* s);
    jsonstring(const char* s, size_t n);
    jsonstring(size_t n, char c);

    ~jsonstring();

    jsonstring& operator=(const jsonstring &str);

    jsonstring& operator+= (const jsonstring& str);  
    jsonstring& operator+= (const char* s); 
    jsonstring& operator+= (char c);

    
    bool operator==(const jsonstring &str);
    bool operator==(const char *str);
    char& operator[] (size_t pos);
    const char& operator[] (size_t pos) const;

    size_t length() const;
    size_t size() const;
    void clear();
    const char *c_str() const;
    const char *data() const;
    jsonstring substr (size_t pos = 0, size_t len = std::string::npos) const;

    jsonstring& append (const jsonstring& str);
    jsonstring& append (const jsonstring& str, size_t subpos, size_t sublen);
    jsonstring& append (const char* s);
    jsonstring& append (const char* s, size_t n); 
    jsonstring& append (size_t n, char c);
	jsonstring& append(const char* s, const char* l);
    jsonstring& assign (const jsonstring& str);
    jsonstring& assign (const jsonstring& str, size_t subpos, size_t sublen); 
    jsonstring& assign (const char* s);
    jsonstring& assign (const char* s, size_t n); 
    jsonstring& assign (size_t n, char c);

    jsonstring& insert (size_t pos, const jsonstring& str); 
    jsonstring& insert (size_t pos, const jsonstring& str,
                          size_t subpos, size_t sublen);  
    jsonstring& insert (size_t pos, const char* s);
    jsonstring& insert (size_t pos, const char* s, size_t n);  
    jsonstring& insert (size_t pos, size_t n, char c);

    jsonstring& erase (size_t pos = 0, size_t len = std::string::npos);

    jsonstring& replace (size_t pos, size_t len, const jsonstring& str);
    jsonstring& replace (size_t pos, size_t len, const jsonstring& str,
                           size_t subpos, size_t sublen); 
    jsonstring& replace (size_t pos, size_t len, const char* s);
    jsonstring& replace (size_t pos, size_t len, const char* s, size_t n); 
    jsonstring& replace (size_t pos, size_t len, size_t n, char c);

    void swap (jsonstring& str);
    void pop_back();
    size_t copy (char* s, size_t len, size_t pos = 0) const;

       
    size_t find (const jsonstring& str, size_t pos = 0) const;  
    size_t find (const char* s, size_t pos = 0) const;
    size_t find (const char* s, size_t pos, size_t n) const; 
    size_t find (char c, size_t pos = 0) const;

	size_t rfind (const jsonstring& str, size_t pos = std::string::npos) const;
	size_t rfind (const char* s, size_t pos = std::string::npos) const;
	size_t rfind (const char* s, size_t pos, size_t n) const;
	size_t rfind (char c, size_t pos = std::string::npos) const;

    size_t find_first_of (const jsonstring& str, size_t pos = 0) const;  
    size_t find_first_of (const char* s, size_t pos = 0) const;
    size_t find_first_of (const char* s, size_t pos, size_t n) const; 
    size_t find_first_of (char c, size_t pos = 0) const;

    size_t find_last_of (const jsonstring& str, size_t pos = std::string::npos) const;
    size_t find_last_of (const char* s, size_t pos = std::string::npos) const;
    size_t find_last_of (const char* s, size_t pos, size_t n) const; 
    size_t find_last_of (char c, size_t pos = std::string::npos) const;

    size_t find_first_not_of (const jsonstring& str, size_t pos = 0) const;   
    size_t find_first_not_of (const char* s, size_t pos = 0) const;
    size_t find_first_not_of (const char* s, size_t pos, size_t n) const; 
    size_t find_first_not_of (char c, size_t pos = 0) const;

    size_t find_last_not_of (const jsonstring& str, size_t pos = std::string::npos) const;
    size_t find_last_not_of (const char* s, size_t pos = std::string::npos) const;
    size_t find_last_not_of (const char* s, size_t pos, size_t n) const; 
    size_t find_last_not_of (char c, size_t pos = std::string::npos) const;

    int compare (const jsonstring& str) const;
    int compare (size_t pos, size_t len, const jsonstring& str) const;
    int compare (size_t pos, size_t len, const jsonstring& str,
                 size_t subpos, size_t sublen) const;  
    int compare (const char* s) const;
    int compare (size_t pos, size_t len, const char* s) const;  
    int compare (size_t pos, size_t len, const char* s, size_t n) const;

    void resize (size_t n);
    void resize (size_t n, char c);

	bool empty() const;
    operator const char *() {return m_string.c_str();}
    void push_back(char ch);
    void reserve(size_t len);
    size_t capacity();
    char at (size_t pos);
	const char &at (size_t pos) const;

    char & back();
    const char& back() const;
    char& front();
    const char& front() const;
    
    const std::string &GetRawData() const;
    std::string &GetRawData();
    friend JSON_API jsonstring operator+ (const jsonstring& lhs, const jsonstring& rhs);
    friend JSON_API jsonstring operator+ (const jsonstring& lhs, const char* rhs);
    friend JSON_API jsonstring operator+ (const char* lhs, const jsonstring& rhs);
    friend JSON_API jsonstring operator+ (const jsonstring& lhs, char rhs);
    friend JSON_API jsonstring operator+ (char lhs, const jsonstring& rhs);

    friend JSON_API bool operator== (const jsonstring& lhs,
        const jsonstring& rhs);
    friend JSON_API bool operator== (const char* lhs, const jsonstring& rhs);
    friend JSON_API bool operator== (const jsonstring& lhs, const char* rhs);

    friend JSON_API bool operator!= (const jsonstring& lhs,
    	const jsonstring& rhs);

    friend JSON_API bool operator!= (const char* lhs, const jsonstring& rhs);

    friend JSON_API bool operator!= (const jsonstring& lhs, const char* rhs);


    friend JSON_API bool operator<  (const jsonstring& lhs,
        const jsonstring& rhs);

    friend JSON_API bool operator<  (const char* lhs, const jsonstring& rhs);

    friend JSON_API bool operator<  (const jsonstring& lhs, const char* rhs);

    friend JSON_API bool operator<= (const jsonstring& lhs,
        const jsonstring& rhs);

    friend JSON_API bool operator<= (const char* lhs, const jsonstring& rhs);
    friend JSON_API bool operator<= (const jsonstring& lhs, const char* rhs);

    friend JSON_API bool operator>  (const jsonstring& lhs,
        const jsonstring& rhs);
    friend JSON_API bool operator>  (const char* lhs, const jsonstring& rhs);
    friend JSON_API bool operator>  (const jsonstring& lhs, const char* rhs);
    friend JSON_API bool operator>= (const jsonstring& lhs,
    	const jsonstring& rhs);
    friend JSON_API bool operator>= (const char* lhs, const jsonstring& rhs);
    friend JSON_API bool operator>= (const jsonstring& lhs, const char* rhs);
public:
    void Tolower();
private:
    std::string m_string;
};

JSON_API std::ostream& operator<< (std::ostream& os,const jsonstring& str);

JSON_API jsonstring operator+ (const jsonstring& lhs, const jsonstring& rhs);
JSON_API jsonstring operator+ (const jsonstring& lhs, const char* rhs);
JSON_API jsonstring operator+ (const char* lhs, const jsonstring& rhs);
JSON_API jsonstring operator+ (const jsonstring& lhs, char rhs);
JSON_API jsonstring operator+ (char lhs, const jsonstring& rhs);
JSON_API bool operator== (const jsonstring& lhs,
	const jsonstring& rhs);
JSON_API bool operator== (const char* lhs, const jsonstring& rhs);
JSON_API bool operator== (const jsonstring& lhs, const char* rhs);

JSON_API bool operator!= (const jsonstring& lhs,
	const jsonstring& rhs);

JSON_API bool operator!= (const char* lhs, const jsonstring& rhs);

JSON_API bool operator!= (const jsonstring& lhs, const char* rhs);


JSON_API bool operator<  (const jsonstring& lhs,
    const jsonstring& rhs);

JSON_API bool operator<  (const char* lhs, const jsonstring& rhs);

JSON_API bool operator<  (const jsonstring& lhs, const char* rhs);

JSON_API bool operator<= (const jsonstring& lhs,
    const jsonstring& rhs);

JSON_API bool operator<= (const char* lhs, const jsonstring& rhs);
JSON_API bool operator<= (const jsonstring& lhs, const char* rhs);

JSON_API bool operator>  (const jsonstring& lhs,
    const jsonstring& rhs);
JSON_API bool operator>  (const char* lhs, const jsonstring& rhs);
JSON_API bool operator>  (const jsonstring& lhs, const char* rhs);
JSON_API bool operator>= (const jsonstring& lhs,
    const jsonstring& rhs);
JSON_API bool operator>= (const char* lhs, const jsonstring& rhs);
JSON_API bool operator>= (const jsonstring& lhs, const char* rhs);
} // namespace Json



#endif // JSON_WRITER_H_INCLUDED