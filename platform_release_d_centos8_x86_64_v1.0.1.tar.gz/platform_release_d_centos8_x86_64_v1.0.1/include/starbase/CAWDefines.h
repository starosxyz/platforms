/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWDEFINES_H
#define CAWDEFINES_H

#include "starbase/CAWTypedef.h"
#include "starbase/CAWByteOrder.h"

//////////////////////////////////////////////////////////////////////
// First definition: choose OS
//////////////////////////////////////////////////////////////////////
#define USE_PLATFORMS 1
#define CAW_UNIX 1

#define CAW_UNIX 1
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <time.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <ctype.h>
#include <sys/poll.h>
#include <linux/unistd.h>
#include <linux/types.h>
//#include <linux/sysctl.h>
#include <sys/syscall.h>
#include <dirent.h>
#include <sys/wait.h>
#define EWOULDBLOCK EAGAIN
#include <sys/uio.h>
#include <assert.h>


typedef long CAWResult;
typedef unsigned long long  WORD64;
typedef long long           SWORD64;
typedef unsigned int        WORD32;
typedef int                 SWORD32;
typedef unsigned short      WORD16;
typedef short               SWORD16;


typedef unsigned char       BYTE;
typedef char                CHAR;


//////////////////////////////////////////////////////////////////////
// OS API definition
//////////////////////////////////////////////////////////////////////

typedef int CAW_HANDLE;
typedef CAW_HANDLE CAW_SOCKET;
#define CAW_INVALID_HANDLE -1
#define CAW_SD_RECEIVE 0
#define CAW_SD_SEND 1
#define CAW_SD_BOTH 2

typedef long long           LONGLONG;
typedef unsigned long       DWORD;
typedef long                LONG;
typedef int                 BOOL;
typedef unsigned char       BYTE;
typedef unsigned short        WORD;
typedef float                 FLOAT;
typedef int                   INT;
typedef unsigned int          UINT;
typedef FLOAT                *PFLOAT;
typedef BOOL                 *LPBOOL;
typedef int                  *LPINT;
typedef WORD                 *LPWORD;
typedef long                 *LPLONG;
typedef DWORD                *LPDWORD;
typedef unsigned int         *LPUINT;
typedef void                 *LPVOID;
typedef const void           *LPCVOID;
typedef char                  CHAR;
typedef char                  TCHAR;
typedef unsigned short        WCHAR;
typedef const char           *LPCSTR;
typedef char                 *LPSTR;
typedef const unsigned short *LPCWSTR;
typedef unsigned short       *LPWSTR;
typedef BYTE                 *LPBYTE;
typedef const BYTE           *LPCBYTE;

#ifndef FALSE
#define FALSE 0
#endif // FALSE
#ifndef TRUE
#define TRUE 1
#endif // TRUE


#if defined (CAW_OS_BUILD_DLL)
	#if __GNUC__ >= 4
	  #define CAW_OS_EXPORT __attribute__ ((visibility("default")))
	#else
	  #define CAW_OS_EXPORT
	#endif
#else
  #define CAW_OS_EXPORT
#endif

#define CAW_OS_SEPARATE '/'

#define CAW_BIT_ENABLED(dword, bit) (((dword) & (bit)) != 0)
#define CAW_BIT_DISABLED(dword, bit) (((dword) & (bit)) == 0)
#define CAW_BIT_CMP_MASK(dword, bit, mask) (((dword) & (bit)) == mask)
#define CAW_SET_BITS(dword, bits) (dword |= (bits))
#define CAW_CLR_BITS(dword, bits) (dword &= ~(bits))


// This is defined by XOPEN to be a minimum of 16.  POSIX.1g
// also defines this value.  platform-specific config.h can
// override this if need be.
#if !defined (IOV_MAX)
#define IOV_MAX 16
#endif // !IOV_MAX
#define CAW_IOV_MAX IOV_MAX

typedef pthread_t CAW_THREAD_ID;
typedef CAW_THREAD_ID CAW_THREAD_HANDLE;
typedef pid_t CAW_PID;
  
//////////////////////////////////////////////////////////////////////
// Assert
//////////////////////////////////////////////////////////////////////


#include <assert.h>
#if defined (CAW_DEBUG) && !defined (CAW_DISABLE_ASSERTE)
#define CAW_ASSERTE assert
#endif // CAW_DEBUG

#ifdef CAW_DISABLE_ASSERTE
  #include "CAWDebug.h"
  #define CAW_ASSERTE(expr) \
    do { \
        if (!(expr)) { \
            CAW_ERROR_TRACE(__FILE__ << ':' << __LINE__ << " Assert failed: " << #expr); \
        } \
    } while (0)
#endif // CAW_DISABLE_ASSERTE

#ifndef CAW_ASSERTE
  #define CAW_ASSERTE(expr) 
#endif // CAW_ASSERTE

//#define CAW_ASSERTE_THROW CAW_ASSERTE

#ifdef CAW_DISABLE_ASSERTE
  #define CAW_ASSERTE_RETURN(expr, rv) \
    do { \
        if (!(expr)) { \
            CAW_ERROR_TRACE(__FILE__ << ":" << __LINE__ << " Assert failed: " << #expr); \
            return rv; \
        } \
    } while (0)

  #define CAW_ASSERTE_RETURN_VOID(expr) \
    do { \
        if (!(expr)) { \
            CAW_ERROR_TRACE(__FILE__ << ":" << __LINE__ << " Assert failed: " << #expr); \
            return; \
        } \
    } while (0)
#else
  #define CAW_ASSERTE_RETURN(expr, rv) \
    do { \
        CAW_ASSERTE((expr)); \
        if (!(expr)) { \
            CAW_ERROR_TRACE(__FILE__ << ":" << __LINE__ << " Assert failed: " << #expr); \
            return rv; \
        } \
    } while (0)

  #define CAW_ASSERTE_RETURN_VOID(expr) \
    do { \
        CAW_ASSERTE((expr)); \
        if (!(expr)) { \
            CAW_ERROR_TRACE(__FILE__ << ":" << __LINE__ << " Assert failed: " << #expr); \
            return; \
        } \
    } while (0)

#endif // CAW_DISABLE_ASSERTE

#ifndef CAW_WIN32
#ifndef UINT_MAX
#define	UINT_MAX	4294967295U
#endif

#ifndef UINT32_MAX
#define	UINT32_MAX	4294967295U
#endif

#endif

static inline uint64_t
caw_htonll(uint64_t n)
{
    return htonl(1) == 1 ? n : ((uint64_t) htonl(n) << 32) | htonl(n >> 32);
}

static inline uint64_t
caw_ntohll(uint64_t n)
{ 
    return htonl(1) == 1 ? n : ((uint64_t) ntohl(n) << 32) | ntohl(n >> 32);
}

#define CAW_UNUSED_ARG(a) (void)(a)

template<class T> inline T caw_min(T a, T b) { return (a > b) ? b : a; }
template<class T> inline T caw_max(T a, T b) { return (a < b) ? b : a; }

#define DISALLOW_ASSIGN(TypeName) \
  void operator=(const TypeName&)

// A macro to disallow the evil copy constructor and operator= functions
// This should be used in the private: declarations for a class.
// Undefine this, just in case. Some third-party includes have their own
// version.
#undef DISALLOW_COPY_AND_ASSIGN
#define DISALLOW_COPY_AND_ASSIGN(TypeName)    \
  TypeName(const TypeName&);                    \
  DISALLOW_ASSIGN(TypeName)

// Alternative, less-accurate legacy name.
#define DISALLOW_EVIL_CONSTRUCTORS(TypeName) \
  DISALLOW_COPY_AND_ASSIGN(TypeName)

// A macro to disallow all the implicit constructors, namely the
// default constructor, copy constructor and operator= functions.
//
// This should be used in the private: declarations for a class
// that wants to prevent anyone from instantiating it. This is
// especially useful for classes containing only static methods.
#define DISALLOW_IMPLICIT_CONSTRUCTORS(TypeName) \
  TypeName();                                    \
  DISALLOW_EVIL_CONSTRUCTORS(TypeName)

// Note that we are using PATH_MAX instead of _POSIX_PATH_MAX, since
// _POSIX_PATH_MAX is the *minimun* maximum value for PATH_MAX and is
// defined by POSIX as 256.
#if !defined (PATH_MAX)
#  if defined (_MAX_PATH)
#    define PATH_MAX _MAX_PATH
#  elif defined (MAX_PATH)
#    define PATH_MAX MAX_PATH
#  else /* !_MAX_PATH */
#    define PATH_MAX 1024
#  endif /* _MAX_PATH */
#endif /* !PATH_MAX */

// Leaving this for backward compatibility, but PATH_MAX should always be
// used directly.
#if !defined (MAXPATHLEN)
#  define MAXPATHLEN  PATH_MAX
#endif /* !MAXPATHLEN */

// This is defined by XOPEN to be a minimum of 16.  POSIX.1g
// also defines this value.  platform-specific config.h can
// override this if need be.
#if !defined (IOV_MAX)
#  define IOV_MAX 16
#endif /* IOV_MAX */

#if defined(__has_cpp_attribute)
#  if __has_cpp_attribute(nodiscard)
#    define NODISCARD [[nodiscard]]
#  endif
#endif
#ifndef NODISCARD
#  if defined(_MSC_VER) && _MSC_VER >= 1700
#    define NODISCARD _Check_return_
#  else
#    define NODISCARD __attribute__((warn_unused_result))
#  endif
#endif

#endif // !CAWDEFINES_H

