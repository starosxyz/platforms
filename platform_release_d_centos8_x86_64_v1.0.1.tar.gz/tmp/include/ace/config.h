#define ACE_HAS_IPV6 1
#define ACE_USES_IPV4_IPV6_MIGRATION 1
#ifdef WIN32
#include "ace/config-win32.h"
#else
#include "ace/config-linux.h"
#endif