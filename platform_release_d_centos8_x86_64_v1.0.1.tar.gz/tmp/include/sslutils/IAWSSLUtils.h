/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/

#ifndef IAWSSLUTILS_H
#define IAWSSLUTILS_H

#include "wface/CAWACEWrapper.h"

class IAWSSLTransportSink;
class IAWSSLTransport;
class IAWSSLConnector;
class IAWSSLAcceptor;
class IAWSSLConnectionSink;

class CAW_OS_EXPORT IAWSSLManager
{
public:
    static IAWSSLManager &Instance();
    virtual ~IAWSSLManager(){}
    virtual CAWResult CreateSSLConnector(CAWAutoPtr<IAWSSLConnector> &aClient) = 0;
    virtual CAWResult CreateSSLAcceptor(CAWAutoPtr<IAWSSLAcceptor> &aAcceptor) = 0;
};

class CAW_OS_EXPORT IAWSSLTransportSink 
{
public:
    virtual void OnSSLDataReceive(CAWMessageBlock &aData, IAWSSLTransport *ptrans) = 0;
    virtual void OnSSLDisconnect(CAWResult aReason, IAWSSLTransport *ptrans) = 0;
    virtual void OnSSLDataSend(IAWSSLTransport *ptrans)=0;

protected:
    virtual ~IAWSSLTransportSink() {}
};

class CAW_OS_EXPORT IAWSSLTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IAWSSLTransportSink *aSink) = 0;
    virtual CAWResult SendSSLData(CAWMessageBlock &aData, CAWTransportParameter *aPara=NULL) = 0;
    virtual CAWResult Disconnect(CAWResult aReason) = 0;
    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAW_HANDLE GetTransportHandle() const=0;

protected:
    virtual ~IAWSSLTransport() {}
};

class CAW_OS_EXPORT IAWSSLAcceptor : public IAWReferenceControl
{
public:
    virtual CAWResult StartListen(
        IAWSSLConnectionSink *aSink,
        const CAWInetAddr &aAddrListen,
        CAWConnectionManager::CType type,
        CAWTimeValue *pTimeout=NULL) = 0;

    virtual CAWResult StopListen(CAWResult aReason) = 0;
    virtual CAWResult LoadVerifyLocations(const CAWString &caroot)=0;
    virtual void SetVerifyPeer (int strict = 0, int once = 1, int depth = 0) = 0;
    virtual CAWResult PrivateKey (const CAWString &file_name) = 0;
    virtual CAWResult Certificate (const CAWString &file_name) = 0;

protected:
    virtual ~IAWSSLAcceptor() {}
};

class CAW_OS_EXPORT IAWSSLConnector : public IAWReferenceControl
{
public:
    virtual CAWResult StartConnect(
        IAWSSLConnectionSink *aSink,
        const CAWInetAddr &aAddrListen,
        CAWConnectionManager::CType type,
        CAWTimeValue *pTimeout=NULL,
        CAWInetAddr *aAddrLocal=NULL) = 0;

    virtual CAWResult StopConnect(CAWResult aReason) = 0;
    virtual CAWResult LoadVerifyLocations(const CAWString &caroot)=0;
    virtual void SetVerifyPeer (int strict = 0, int once = 1, int depth = 0) = 0;
    virtual CAWResult PrivateKey (const CAWString &file_name) = 0;
    virtual CAWResult Certificate (const CAWString &file_name) = 0;

protected:
    virtual ~IAWSSLConnector() {}
};

class CAW_OS_EXPORT IAWSSLConnectionSink
{
public:
    /// Channel of server is created.
    /// You should invoke AsyncOpen() in this function.
    virtual void OnSSLConnected(CAWResult result,IAWSSLTransport *aTransport) = 0;

protected:
    virtual ~IAWSSLConnectionSink() { }
};

#endif // IAWSSLUTILS_H
