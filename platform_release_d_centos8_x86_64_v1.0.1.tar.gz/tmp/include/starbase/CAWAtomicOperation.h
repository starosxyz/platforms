/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWATOMICOPERATION_H
#define CAWATOMICOPERATION_H

#include "starbase/CAWDefines.h"

class CAW_OS_EXPORT CAWAtomicOperation
{
public:
    CAWAtomicOperation(int32_t aValue = 0) 
        : m_lValue(aValue)
    {
    }

    int32_t operator++ ()
    {
#ifdef CAW_WIN32
    return ::InterlockedIncrement(reinterpret_cast<volatile LONG*>(&this->m_lValue));
#else
    return __sync_add_and_fetch(&m_lValue, 1);
#endif // CAW_WIN32
    }

    int32_t operator++ (int)
    {
    return ++*this - 1;
    }

    int32_t operator-- (void)
    {
#ifdef CAW_WIN32
    return ::InterlockedDecrement(reinterpret_cast<volatile LONG*>(&this->m_lValue));
#else
    return __sync_sub_and_fetch(&m_lValue, 1);
#endif // CAW_WIN32
    }

    int32_t operator-- (int)
    {
        return --*this + 1;
    }

    int32_t operator+= (int32_t aRight)
    {
#ifdef CAW_WIN32
    return ::InterlockedExchangeAdd(reinterpret_cast<volatile LONG*>(&this->m_lValue), aRight) + aRight;
#else
    return __sync_fetch_and_add(&m_lValue, aRight) + aRight;
#endif // CAW_WIN32
    }

    int32_t operator-= (int32_t aRight)
    {
#ifdef CAW_WIN32
    return ::InterlockedExchangeAdd(reinterpret_cast<volatile LONG*>(&this->m_lValue), -aRight) - aRight;
#else
    return __sync_fetch_and_add(&m_lValue, -aRight) - aRight;
#endif // CAW_WIN32
    }

    bool operator== (int32_t aRight) const
    {
        return (this->m_lValue == aRight);
    }

    bool operator!= (int32_t aRight) const
    {
        return (this->m_lValue != aRight);
    }

    bool operator>= (int32_t aRight) const
    {
        return (this->m_lValue >= aRight);
    }

    bool operator> (int32_t aRight) const
    {
        return (this->m_lValue > aRight);
    }

    bool operator<= (int32_t aRight) const
    {
        return (this->m_lValue <= aRight);
    }

    bool operator< (int32_t aRight) const
    {
        return (this->m_lValue < aRight);
    }

    void operator= (int32_t aRight)
    {
#ifdef CAW_WIN32
    ::InterlockedCompareExchange(reinterpret_cast<volatile LONG*>(&this->m_lValue),aRight, m_lValue);
#else
    __sync_bool_compare_and_swap(&m_lValue, m_lValue, aRight);
#endif // CAW_WIN32
    }

    void operator= (const CAWAtomicOperation &aRight)
    {
#ifdef CAW_WIN32
        ::InterlockedCompareExchange(reinterpret_cast<volatile LONG*>(&this->m_lValue), aRight.m_lValue,m_lValue);
#else
         __sync_bool_compare_and_swap(&m_lValue, m_lValue, aRight.m_lValue);
#endif // CAW_WIN32
    }

    int32_t GetValue() const
    {
        return this->m_lValue;
    }
    
private:
    volatile int32_t m_lValue;
};


#endif //CAWATOMICOPERATION_H


