/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/

#ifndef CAWTHREADINTERFACE_H
#define CAWTHREADINTERFACE_H

#include "starbase/CAWDefines.h"

class CAWTimeValue;
class CAW_OS_EXPORT IAWEvent
{
public:
    virtual CAWResult OnEventFire() = 0;
    virtual void OnDestorySelf();
protected:
    virtual ~IAWEvent() { }
};

class CAW_OS_EXPORT IAWEventQueue
{
public:
    enum EPriority
    {
        EPRIORITY_HIGH,
        EPRIORITY_NORMAL,
        EPRIORITY_LOW,
    };

    virtual CAWResult PostEvent(IAWEvent *aEvent, EPriority aPri = EPRIORITY_NORMAL) = 0;

    virtual CAWResult SendEvent(IAWEvent *aEvent) = 0;
    virtual DWORD GetPendingEventsCount() = 0;

    protected:
    virtual ~IAWEventQueue() { }
};


class CAW_OS_EXPORT IAWTimerHandler
{
public:
    virtual void OnTimeout(const CAWTimeValue &aCurTime, LPVOID aArg) = 0;

protected:
    virtual ~IAWTimerHandler() { }
};

class CAW_OS_EXPORT IAWTimerQueue
{
public:
    virtual CAWResult ScheduleTimer(IAWTimerHandler *aTh, 
            LPVOID aArg,
            const CAWTimeValue &aInterval,
            DWORD aCount) = 0;
    virtual CAWResult CancelTimer(IAWTimerHandler *aTh) = 0;

protected:
    virtual ~IAWTimerQueue() { }
};

#endif // CAWTHREADINTERFACE_H

