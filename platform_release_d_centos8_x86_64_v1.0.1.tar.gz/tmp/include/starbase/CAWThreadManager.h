/***********************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd 
**********************************************************************/
#ifndef CAWTHREADMANAGER_H
#define CAWTHREADMANAGER_H

#include "starbase/CAWDefines.h"
#include "starbase/CAWMutex.h"
#include "starbase/CAWThreadInterface.h"
#include "starbase/CAWReactorInterface.h"
#include "starbase/CAWTimeValue.h"
#include "starbase/CAWString.h"

class CAWThread;
class CAW_OS_EXPORT CAWThreadManager  
{
public:
    typedef int TType;
    enum 
    {
        TT_MAIN,
        TT_NETWORK,
        TT_IPC,
        TT_DNS,
        TT_CURRENT,
        TT_TIMER,
        TT_UNKNOWN = -1,

        // This private thread type is used by applications. 
        TT_USER_DEFINE_BASE = 0x1000,
    };

    enum TFlag
    {
        TF_NONE = 0,
        TF_JOINABLE = (1 << 0),
        TF_DETACHED = (1 << 1),
    };

    virtual ~CAWThreadManager(){}
    virtual CAWResult InitMainThread(int aArgc, char** aArgv) = 0;
    virtual CAWResult MainThreadDetachRun(CAWThread *pThread) = 0;
    virtual CAWThread* GetThread(TType aType) = 0;
    virtual IAWReactor* GetThreadReactor(TType aType) = 0;
    virtual IAWEventQueue* GetThreadEventQueue(TType aType) = 0;
    virtual IAWTimerQueue* GetThreadTimerQueue(TType aType) = 0;
    virtual CAWResult CreateUserTaskThread(
        CAWThread *&aThread, 
        TFlag aFlag = TF_JOINABLE,
        BOOL bWithTimerQueue = TRUE) = 0;

    // get user thread type (TT_USER_DEFINE_BASE + x)
    virtual TType GetAndIncreamUserType() = 0;
    virtual CAWResult DisableSignal(int SigNum) = 0;

	// the following member functions are mainly used in TP.
	virtual CAWResult CreateNetworkThread(TType aType,
		IAWReactor *aReactor,
		CAWThread *&aThread) = 0;

	virtual CAWResult CreateReactorThread(TType aType, IAWReactor *aReactor, CAWThread *&aThread) = 0;

    // mainly invoked by CAWThreadManager::~CAWThreadManager()
    virtual CAWResult StopAllThreads(CAWTimeValue* aTimeout = NULL) = 0;
    virtual CAWResult JoinAllThreads() = 0;

    // mainly invoked by CAWThread::Create().
    virtual CAWResult RegisterThread(CAWThread* aThread) = 0;

    virtual CAWResult UnregisterThread(CAWThread* aThread) = 0;

    virtual void GetSingletonMutex(CAWMutexThreadRecursive *&aMutex) = 0;

    virtual void GetReferenceControlMutex(CAWMutexThread *&aMutex) = 0;
public:
    static void SleepMs(DWORD aMsec);
    static CAW_THREAD_ID GetThreadSelfId();
    static BOOL IsThreadEqual(CAW_THREAD_ID aT1, CAW_THREAD_ID aT2);
    static BOOL IsEqualCurrentThread(CAW_THREAD_ID aId);
    static BOOL IsEqualCurrentThread(TType aType);
    // mainly for init winsock2
    static CAWResult SocketStartup();
    static CAWResult SocketCleanup();
    static CAWThreadManager* Instance();
	// thread module
	enum TModule
	{
		TM_SINGLE_MAIN,
		TM_MULTI_ONE_DEDICATED,
		TM_MULTI_POOL,
	};
	static TModule GetNetworkThreadModule();
	static IAWReactor* CreateNetworkReactor();
};

#endif // !CAWTHREADMANAGER_H

