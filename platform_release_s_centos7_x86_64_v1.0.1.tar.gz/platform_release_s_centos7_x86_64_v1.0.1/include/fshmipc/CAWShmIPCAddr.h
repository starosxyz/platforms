/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWSHMIPCADDR_H
#define CAWSHMIPCADDR_H
#include "fipc/CAWIPCAddr.h"

class CAW_OS_EXPORT CAWShmIPCAddr  
{
public:
    CAWShmIPCAddr();
	~CAWShmIPCAddr();
    CAWShmIPCAddr(uint16_t jno, uint16_t serviceno);
    CAWShmIPCAddr(const CAWShmIPCAddr &ipaddr)
    {
        (*this)=ipaddr;
    }
    CAWShmIPCAddr& operator=(const CAWShmIPCAddr& right)
    {
        m_jno=right.m_jno;
        m_serviceno=right.m_serviceno;
        return (*this);  
    }
    bool operator == (const CAWShmIPCAddr &aRight) const;
    
    inline uint16_t GetJno() const {return m_jno;}
    inline uint16_t GetServiceNo() const {return m_serviceno;}
    CAWIPCAddr ConvertToIPCAddr();
    void FromIPCAddr(const CAWIPCAddr &ipcaddr);
    CAWString ToString();
private:
    uint16_t m_jno;
    uint16_t m_serviceno;
};


#endif // !CAWIPCADDR_H

