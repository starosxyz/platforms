/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAW_BYTEORDER_H_
#define CAW_BYTEORDER_H_

// mainly copied from ace/Basic_Types.h
// Byte-order (endian-ness) determination.

# if defined (BYTE_ORDER)
#   if (BYTE_ORDER == LITTLE_ENDIAN)
#     define CAW_LITTLE_ENDIAN 0x0123
#     define CAW_BYTE_ORDER CAW_LITTLE_ENDIAN
#   elif (BYTE_ORDER == BIG_ENDIAN)
#     define CAW_BIG_ENDIAN 0x3210
#     define CAW_BYTE_ORDER CAW_BIG_ENDIAN
#   else
#     error: unknown BYTE_ORDER!
#   endif /* BYTE_ORDER */
# elif defined (_BYTE_ORDER)
#   if (_BYTE_ORDER == _LITTLE_ENDIAN)
#     define CAW_LITTLE_ENDIAN 0x0123
#     define CAW_BYTE_ORDER CAW_LITTLE_ENDIAN
#   elif (_BYTE_ORDER == _BIG_ENDIAN)
#     define CAW_BIG_ENDIAN 0x3210
#     define CAW_BYTE_ORDER CAW_BIG_ENDIAN
#   else
#     error: unknown _BYTE_ORDER!
#   endif /* _BYTE_ORDER */
# elif defined (__BYTE_ORDER)
#   if (__BYTE_ORDER == __LITTLE_ENDIAN)
#     define CAW_LITTLE_ENDIAN 0x0123
#     define CAW_BYTE_ORDER CAW_LITTLE_ENDIAN
#   elif (__BYTE_ORDER == __BIG_ENDIAN)
#     define CAW_BIG_ENDIAN 0x3210
#     define CAW_BYTE_ORDER CAW_BIG_ENDIAN
#   else
#     error: unknown __BYTE_ORDER!
#   endif /* __BYTE_ORDER */
# elif defined (__BYTE_ORDER__)
#   if (__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__)
#     define CAW_LITTLE_ENDIAN 0x0123
#     define CAW_BYTE_ORDER CAW_LITTLE_ENDIAN
#   elif (__BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
#     define CAW_BIG_ENDIAN 0x3210
#     define CAW_BYTE_ORDER CAW_BIG_ENDIAN
#   else
#     error: unknown __BYTE_ORDER__!
#   endif /* __BYTE_ORDER */
# else /* ! BYTE_ORDER && ! __BYTE_ORDER */
  // We weren't explicitly told, so we have to figure it out . . .
#   if defined (i386) || defined (__i386__) ||defined (__x86_64__) || defined (_M_IX86) || \
     defined (vax) || defined (__alpha) || defined (__LITTLE_ENDIAN__) || \
     defined (ARM) || defined (_M_IA64) || defined (_M_AMD64) || \
     defined (__amd64) || \
     ((defined (__ia64__) || defined (__ia64)) && !defined (__hpux))
    // We know these are little endian.
#     define CAW_LITTLE_ENDIAN 0x0123
#     define CAW_BYTE_ORDER CAW_LITTLE_ENDIAN
#   else
    // Otherwise, we assume big endian.
#     define CAW_BIG_ENDIAN 0x3210
#     define CAW_BYTE_ORDER CAW_BIG_ENDIAN
#   endif
# endif /* ! BYTE_ORDER && ! __BYTE_ORDER */
// Reading and writing of little and big-endian numbers from memory
//TODO: Optimized versions, with direct read/writes of
// integers in host-endian format, when the platform supports it.

#if !(defined(CAW_BIG_ENDIAN) ^ defined(CAW_LITTLE_ENDIAN))
#error Define either CAW_BIG_ENDIAN or CAW_LITTLE_ENDIAN
#endif


#endif


