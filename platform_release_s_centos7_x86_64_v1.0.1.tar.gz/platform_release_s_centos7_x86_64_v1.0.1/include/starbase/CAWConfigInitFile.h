/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/

#ifndef CAWCONFIGINITFILE_H
#define CAWCONFIGINITFILE_H

#include "starbase/CAWUtilTemplates.h"
#include <sstream>

class CAW_OS_EXPORT CAWConfigInitFile  
{
public:
    CAWConfigInitFile();
    ~CAWConfigInitFile();
    int GetIntParam(
        const CAWString &aGroup, 
        const CAWString &aKey,
        int aDefault = 0);

    DWORD GetDwordParam(
        const CAWString &aGroup, 
        const CAWString &aKey,
        DWORD aDefault = 0);

    WORD GetWordParam(
        const CAWString &aGroup, 
        const CAWString &aKey,
        WORD aDefault = 0);

    CAWString GetStringParam(
        const CAWString &aGroup, 
        const CAWString &aKey,
        CAWString aDefault = CAWString());

    BOOL GetBoolParam(
        const CAWString &aGroup, 
        const CAWString &aKey,
        BOOL aDefault = FALSE);

};

typedef CAWSingletonT<CAWConfigInitFile> CAWConfigInitFileSingleton;


#endif // CAWCONFIGINITFILE_H

