/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWERROR_H
#define CAWERROR_H

#define CAW_ERROR_MODULE_BASE      10000
#define CAW_ERROR_MODULE_NETWORK   20000
#define CAW_ERROR_MODULE_DB        30000
#define CAW_ERROR_MODULE_OPENFLOW_ENGINE 40000

#define CAW_FAILED(rv) (rv != 0)
#define CAW_SUCCEEDED(rv) (rv == 0)

/* Standard "it worked" return value */
#define CAW_OK                              0

/* Returned when a function fails */
#define CAW_ERROR_FAILURE                   (CAWResult)(CAW_ERROR_MODULE_BASE + 1)

/* Returned when an instance is not initialized */
#define CAW_ERROR_NOT_INITIALIZED           (CAWResult)(CAW_ERROR_MODULE_BASE + 2)

/* Returned when an instance is already initialized */
#define CAW_ERROR_ALREADY_INITIALIZED       (CAWResult)(CAW_ERROR_MODULE_BASE + 3)

/* Returned by a not implemented function */
#define CAW_ERROR_NOT_IMPLEMENTED           (CAWResult)(CAW_ERROR_MODULE_BASE + 4)

#define CAW_ERROR_NULL_POINTER              (CAWResult)(CAW_ERROR_MODULE_BASE + 5)

/* Returned when an unexpected error occurs */
#define CAW_ERROR_UNEXPECTED                (CAWResult)(CAW_ERROR_MODULE_BASE + 6)

/* Returned when a memory allocation fails */
#define CAW_ERROR_OUT_OF_MEMORY             (CAWResult)(CAW_ERROR_MODULE_BASE + 7)

/* Returned when an illegal value is passed */
#define CAW_ERROR_INVALID_ARG               (CAWResult)(CAW_ERROR_MODULE_BASE + 8)

/* Returned when an operation can't complete due to an unavailable resource */
#define CAW_ERROR_NOT_AVAILABLE             (CAWResult)(CAW_ERROR_MODULE_BASE + 9)

#define CAW_ERROR_WOULD_BLOCK               (CAWResult)(CAW_ERROR_MODULE_BASE + 10)

#define CAW_ERROR_NOT_FOUND                 (CAWResult)(CAW_ERROR_MODULE_BASE + 11)

#define CAW_ERROR_FOUND                     (CAWResult)(CAW_ERROR_MODULE_BASE + 12)

#define CAW_ERROR_PARTIAL_DATA              (CAWResult)(CAW_ERROR_MODULE_BASE + 13)

#define CAW_ERROR_TIMEOUT                   (CAWResult)(CAW_ERROR_MODULE_BASE + 14)

#define CAW_ERROR_CONTINUE                  (CAWResult)(CAW_ERROR_MODULE_BASE + 15)

#define CAW_ERROR_SSL_NEGO_FAILURE          (CAWResult)(CAW_ERROR_MODULE_BASE + 16)

#endif // CAWERROR_H

