#ifndef CAWTRACE_H
#define CAWTRACE_H
#include "starbase/CAWDefines.h"

CAW_OS_EXPORT void STrace(const char * format, ...);


#endif//


