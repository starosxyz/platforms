/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWIPCINTERFACE_H
#define CAWIPCINTERFACE_H

#include "starbase/CAWDefines.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWUtilTemplates.h"
#include "starbase/CAWMutex.h"
#include "fipc/CAWIPCAddr.h"

class CAWTimeValue;
class CAWMessageBlock;

class IAWIPCAcceptorConnectorSink;
class IAWIPCTransportSink;
class IAWReferenceControl;
  class IAWIPCTransport;
  class IAWIPCAcceptorConnectorId;
    class IAWIPCConnector;
    class IAWIPCAcceptor;

class CAW_OS_EXPORT CAWIPCManager
{
public:
    static CAWIPCManager* Instance();
    typedef DWORD CType;
    enum { 
        // connection type
        CTYPE_NONE = 0,
        CTYPE_STREAM = (1 << 0),
        CTYPE_DGRAM = (1 << 1),
    };

    /// Create <IAWConnector>.
    virtual CAWResult CreateIPCClient(CType aType, IAWIPCConnector *&aConClient) = 0;

    /// Create <IAWAcceptor>.
    virtual CAWResult CreateIPCServer(CType aType,IAWIPCAcceptor *&aAcceptor) = 0;
    virtual CAWResult CreateIPCClientWithThread(CType aType, 
                        IAWIPCConnector *&aConClient, CAWThread *pNetworkThread) = 0;
    
    /// Create <IAWAcceptor>.
    virtual CAWResult CreateIPCServerWithThread(CType aType,
        IAWIPCAcceptor *&aAcceptor, CAWThread *pNetworkThread) = 0;
protected:
     virtual ~CAWIPCManager(){}
};

class CAW_OS_EXPORT CAWIPCTransportParameter
{
public:
    CAWIPCTransportParameter()
        : m_dwHaveSent(0)
    {
    }

    DWORD m_dwHaveSent;
};

/// the sink classes don't need ReferenceControl
class CAW_OS_EXPORT IAWIPCAcceptorConnectorSink 
{
public:
    virtual void OnIPCConnectIndication(
        CAWResult aReason,
        IAWIPCTransport *aTrpt,
        IAWIPCAcceptorConnectorId *aRequestId) = 0;

protected:
    virtual ~IAWIPCAcceptorConnectorSink() {}
};

class CAW_OS_EXPORT IAWIPCTransportSink 
{
public:
    virtual void OnReceive(
        CAWMessageBlock &aData,
        IAWIPCTransport *aTrptId,
        CAWIPCTransportParameter *aPara = NULL) = 0;

    virtual void OnSend(
        IAWIPCTransport *aTrptId,
        CAWIPCTransportParameter *aPara = NULL) = 0;

    virtual void OnDisconnect(
    CAWResult aReason,
    IAWIPCTransport *aTrptId) = 0;

protected:
    virtual ~IAWIPCTransportSink() {}
};

class CAW_OS_EXPORT IAWIPCTransport : public IAWReferenceControl
{
public:
    virtual CAWResult OpenWithSink(IAWIPCTransportSink *aSink) = 0;

    virtual IAWIPCTransportSink* GetSink() = 0;

    virtual CAWResult SendData(CAWMessageBlock &aData, CAWIPCTransportParameter *aPara = NULL) = 0;

    /// the <aCommand>s are all listed in file CmErrorNetwork.h
    virtual CAWResult SetOption(DWORD aCommand, LPVOID aArg) = 0;
    virtual CAWResult GetOption(DWORD aCommand, LPVOID aArg) = 0;

    /// Disconnect the connection, and will not callback <IAWTransportSink> longer.
    virtual CAWResult Disconnect(CAWResult aReason) = 0;
    virtual CAW_HANDLE GetTransportHandle() const = 0;

protected:
    virtual ~IAWIPCTransport() {}
};


class CAW_OS_EXPORT IAWIPCAcceptorConnectorId : public IAWReferenceControl
{
public:
    virtual BOOL IsConnector() = 0;

protected:
    virtual ~IAWIPCAcceptorConnectorId() {}
};

class CAW_OS_EXPORT IAWIPCConnector : public IAWIPCAcceptorConnectorId
{
public:
    virtual void AsycConnect(
        IAWIPCAcceptorConnectorSink *aSink,
        const CAWIPCAddr &aAddrPeer, 
        CAWTimeValue *aTimeout = NULL,
        CAWIPCAddr *aAddrLocal=NULL) = 0;

    virtual void CancelConnect() = 0;

protected:
    virtual ~IAWIPCConnector() {}
};

class CAW_OS_EXPORT IAWIPCAcceptor : public IAWIPCAcceptorConnectorId
{
public:
    virtual CAWResult StartListen(IAWIPCAcceptorConnectorSink *aSink,const CAWIPCAddr &aAddrListen) = 0;
    virtual CAWResult StopListen(CAWResult aReason) = 0;
protected:
    virtual ~IAWIPCAcceptor() {}
};

class CAW_OS_EXPORT IAWIPCConnectorInternal
{
public:
    virtual int Connect(const CAWIPCAddr &aAddr, CAWIPCAddr *aAddrLocal = NULL) = 0;
    virtual int Close() = 0;
    virtual ~IAWIPCConnectorInternal() { }
};


#endif // CAWIPCINTERFACE_H

