/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWATOMICOPERATIONT_H
#define CAWATOMICOPERATIONT_H

#include "starbase/CAWAtomicOperation.h"

#if defined (CAW_WIN32) // for windows
  #if (_M_IX86 > 400)
    #define CAW_HAS_PENTIUM 1
  #endif // _M_IX86
# define CAW_HAS_INTERLOCKED_EXCHANGEADD
#elif defined (__GNUC__) // for g++
  #if !defined (__MINGW32__) && (defined (i386) || defined (__i386__))
    # define CAW_HAS_PENTIUM 1
  #endif /* i386 */
#endif // CAW_WIN32


#include "starbase/CAWThreadManager.h"

template <class MutexType> 
class CAW_OS_EXPORT CAWAtomicOperationT
{
public:
    CAWAtomicOperationT(long aValue = 0) 
        : m_pMutex(NULL)
        , m_lValue(aValue)
    {
        CAWThreadManager::Instance()->GetReferenceControlMutex(m_pMutex);
    }

    long operator++ ()
    {
        CAWMutexGuardT<MutexType> theGuard(*m_pMutex);
        return ++m_lValue;
    }

    long operator++ (int)
    {
        return ++*this - 1;
    }

    long operator-- (void)
    {
        CAWMutexGuardT<MutexType> theGuard(*m_pMutex);
        return --m_lValue;
    }

    long operator-- (int)
    {
        return --*this + 1;
    }

    int operator== (long aRight) const
    {
        return (this->m_lValue == aRight);
    }

    int operator!= (long aRight) const
    {
        return (this->m_lValue != aRight);
    }

    int operator>= (long aRight) const
    {
        return (this->m_lValue >= aRight);
    }

    int operator> (long aRight) const
    {
        return (this->m_lValue > aRight);
    }

    int operator<= (long aRight) const
    {
        return (this->m_lValue <= aRight);
    }

    int operator< (long aRight) const
    {
        return (this->m_lValue < aRight);
    }

    void operator= (long aRight)
    {
        CAWMutexGuardT<MutexType> theGuard(*m_pMutex);
        m_lValue = aRight;
    }

    void operator= (const CAWAtomicOperationT &aRight)
    {
        CAWMutexGuardT<MutexType> theGuard(*m_pMutex);
        m_lValue = aRight.m_lValue;
    }

    long GetValue() const
    {
        return this->m_lValue;
    }

private:
    MutexType *m_pMutex;
    long m_lValue;
};

#if defined (CAW_WIN32)
  #define CAW_HAS_BUILTIN_ATOMIC_OP 1
#elif defined (__GNUC__) && defined (CAW_HAS_PENTIUM)
  #define CAW_HAS_BUILTIN_ATOMIC_OP 1
#endif // CAW_WIN32

#ifdef CAW_HAS_BUILTIN_ATOMIC_OP
template<>
class CAW_OS_EXPORT CAWAtomicOperationT<CAWMutexThread>
{
public:
    CAWAtomicOperationT(long aValue = 0) 
        : m_lValue(aValue)
    {
    }

    /// Atomically pre-increment <m_lValue>.
    long operator++ ()
    {
#ifdef CAW_WIN32
    return ::InterlockedIncrement(const_cast<long*>(&this->m_lValue));
#else
    return (*increment_fn_)(&this->m_lValue);
#endif // CAW_WIN32
    }

    /// Atomically post-increment <m_lValue>.
    long operator++ (int)
    {
    return ++*this - 1;
    }

    /// Atomically pre-decrement <m_lValue>.
    long operator-- (void)
    {
#ifdef CAW_WIN32
    return ::InterlockedDecrement(const_cast<long*>(&this->m_lValue));
#else
    return (*decrement_fn_)(&this->m_lValue);
#endif // CAW_WIN32
    }

    /// Atomically post-decrement <m_lValue>.
    long operator-- (int)
    {
        return --*this + 1;
    }

    /// Atomically increment <m_lValue> by aRight.
    long operator+= (long aRight)
    {
#ifdef CAW_WIN32
    return ::InterlockedExchangeAdd(const_cast<long*>(&this->m_lValue), aRight) + aRight;
#else
    return (*exchange_add_fn_)(&this->m_lValue, aRight) + aRight;
#endif // CAW_WIN32
    }

    /// Atomically decrement <m_lValue> by aRight.
    long operator-= (long aRight)
    {
#ifdef CAW_WIN32
    return ::InterlockedExchangeAdd(const_cast<long*>(&this->m_lValue), -aRight) - aRight;
#else
    return (*exchange_add_fn_)(&this->m_lValue, -aRight) - aRight;
#endif // CAW_WIN32
    }

    /// Atomically compare <m_lValue> with aRight.
    int operator== (long aRight) const
    {
        return (this->m_lValue == aRight);
    }

    /// Atomically compare <m_lValue> with aRight.
    int operator!= (long aRight) const
    {
        return (this->m_lValue != aRight);
    }

    /// Atomically check if <m_lValue> greater than or equal to aRight.
    int operator>= (long aRight) const
    {
        return (this->m_lValue >= aRight);
    }

    /// Atomically check if <m_lValue> greater than aRight.
    int operator> (long aRight) const
    {
        return (this->m_lValue > aRight);
    }

    /// Atomically check if <m_lValue> less than or equal to aRight.
    int operator<= (long aRight) const
    {
        return (this->m_lValue <= aRight);
    }

    /// Atomically check if <m_lValue> less than aRight.
    int operator< (long aRight) const
    {
        return (this->m_lValue < aRight);
    }

    /// Atomically assign aRight to <m_lValue>.
    void operator= (long aRight)
    {
#ifdef CAW_WIN32
    ::InterlockedExchange(const_cast<long*>(&this->m_lValue), aRight);
#else
    (*exchange_fn_)(&this->m_lValue, aRight);
#endif // CAW_WIN32
    }

    /// Atomically assign <aRight> to <m_lValue>.
    void operator= (const CAWAtomicOperationT &aRight)
    {
#ifdef CAW_WIN32
        ::InterlockedExchange(const_cast<long*>(&this->m_lValue), aRight.m_lValue);
#else
        (*exchange_fn_)(&this->m_lValue, aRight.m_lValue);
#endif // CAW_WIN32
    }

    /// Explicitly return <m_lValue>.
    long GetValue() const
    {
        return this->m_lValue;
    }

    /// Used during <CAWThreadManager> initialization to optimize the fast
    /// atomic op implementation according to the number of CPUs.
    static void init_functions (void);

private:
    // Single-cpu atomic op implementations.
    static long single_cpu_increment (volatile long *value);
    static long single_cpu_decrement (volatile long *value);
    static long single_cpu_exchange (volatile long *value, long aRight);
    static long single_cpu_exchange_add (volatile long *value, long aRight);

    // Multi-cpu atomic op implementations.
    static long multi_cpu_increment (volatile long *value);
    static long multi_cpu_decrement (volatile long *value);
    static long multi_cpu_exchange (volatile long *value, long aRight);
    static long multi_cpu_exchange_add (volatile long *value, long aRight);

    // Pointers to selected atomic op implementations.
    static long (*increment_fn_) (volatile long *);
    static long (*decrement_fn_) (volatile long *);
    static long (*exchange_fn_) (volatile long *, long);
    static long (*exchange_add_fn_) (volatile long *, long);

private:
    /// Current object decorated by the atomic opearation.
    volatile long m_lValue;
};

#endif // CAW_HAS_BUILTIN_ATOMIC_OP

#include "CAWUtilClasses.h"

/// Specialization of <CAWAtomicOperationT> for single-thread.
/// Every <CAWAtomicOperationT> has its own <CAWMutexNullSingleThread>.
template<>
class CAW_OS_EXPORT CAWAtomicOperationT<CAWMutexNullSingleThread>
{
public:
    CAWAtomicOperationT(long aValue = 0) 
        : m_lValue(aValue)
    {
    }

    /// Atomically pre-increment <m_lValue>.
    long operator++ ()
    {
        m_Est.EnsureSingleThread();
        return ++this->m_lValue;
    }

    /// Atomically post-increment <m_lValue>.
    long operator++ (int)
    {
        m_Est.EnsureSingleThread();
        return this->m_lValue++;
    }

    /// Atomically increment <m_lValue> by aRight.
    long operator+= (long aRight)
    {
        m_Est.EnsureSingleThread();
        return this->m_lValue += aRight;
    }

    /// Atomically pre-decrement <m_lValue>.
    long operator-- (void)
    {
        m_Est.EnsureSingleThread();
        return --this->m_lValue;
    }

    /// Atomically post-decrement <m_lValue>.
    long operator-- (int)
    {
        m_Est.EnsureSingleThread();
        return this->m_lValue--;
    }

    /// Atomically decrement <m_lValue> by aRight.
    long operator-= (long aRight)
    {
        m_Est.EnsureSingleThread();
        return this->m_lValue -= aRight;
    }

    /// Atomically compare <m_lValue> with aRight.
    int operator== (long aRight) const
    {
        m_Est.EnsureSingleThread();
        return this->m_lValue == aRight;
    }

    /// Atomically compare <m_lValue> with aRight.
    int operator!= (long aRight) const
    {
        m_Est.EnsureSingleThread();
        return !(*this == aRight);
    }

    /// Atomically check if <m_lValue> greater than or equal to aRight.
    int operator>= (long aRight) const
    {
        m_Est.EnsureSingleThread();
        return this->m_lValue >= aRight;
    }

    /// Atomically check if <m_lValue> greater than aRight.
    int operator> (long aRight) const
    {
        m_Est.EnsureSingleThread();
        return this->m_lValue > aRight;
    }

    /// Atomically check if <m_lValue> less than or equal to aRight.
    int operator<= (long aRight) const
    {
        m_Est.EnsureSingleThread();
        return this->m_lValue <= aRight;
    }

    /// Atomically check if <m_lValue> less than aRight.
    int operator< (long aRight) const
    {
        m_Est.EnsureSingleThread();
        return this->m_lValue < aRight;
    }

    /// Atomically assign aRight to <m_lValue>.
    void operator= (long aRight)
    {
        m_Est.EnsureSingleThread();
        this->m_lValue = aRight;
    }

    /// Atomically assign <aRight> to <m_lValue>.
    void operator= (const CAWAtomicOperationT &aRight)
    {
        if (&aRight == this)
            return; // Avoid deadlock...

        m_Est.EnsureSingleThread();
        this->m_lValue = aRight.GetValue();
    }

    /// Explicitly return <m_lValue>.
    long GetValue() const
    {
        m_Est.EnsureSingleThread();
        return this->m_lValue;
    }

private:
    CAWEnsureSingleThread m_Est;
    /// Current object decorated by the atomic opearation.
    volatile long m_lValue;
};

#endif //CAWATOMICOPERATIONT_H


