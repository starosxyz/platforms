/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWTIMEVALUE_H
#define CAWTIMEVALUE_H

#include "starbase/CAWDefines.h"

#define CAW_ONE_SECOND_IN_MSECS 1000L
#define CAW_ONE_SECOND_IN_USECS 1000000L
#define CAW_ONE_SECOND_IN_NSECS 1000000000L

#ifdef _MSC_VER
  // -------------------------------------------------------------------
  // These forward declarations are only used to circumvent a bug in
  // MSVC 6.0 compiler.  They shouldn't cause any problem for other
  // compilers.
  class CAWTimeValue;
  CAW_OS_EXPORT CAWTimeValue operator + (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
  CAW_OS_EXPORT CAWTimeValue operator - (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
  CAW_OS_EXPORT int operator < (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
  CAW_OS_EXPORT int operator > (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
  CAW_OS_EXPORT int operator <= (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
  CAW_OS_EXPORT int operator >= (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
  CAW_OS_EXPORT int operator == (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
  CAW_OS_EXPORT int operator != (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
#endif // _MSC_VER

class CAW_OS_EXPORT CAWTimeValue  
{
public:
    // add the follwoing two functions to avoid call Normalize().
    CAWTimeValue();
    CAWTimeValue(long aSec);
    CAWTimeValue(long aSec, long aUsec);
    CAWTimeValue(const timeval &aTv);
    CAWTimeValue(double aSec);

    void Set(long aSec, long aUsec);
    void Set(const timeval &aTv);
    void Set(double aSec);

    long GetSec() const ;
    long GetUsec() const ;

    void SetByTotalMsec(long aMilliseconds);
    long GetTotalInMsec() const;

    void operator += (const CAWTimeValue &aRight);
    void operator -= (const CAWTimeValue &aRight);

    friend CAW_OS_EXPORT CAWTimeValue operator + (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
    friend CAW_OS_EXPORT CAWTimeValue operator - (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
    friend CAW_OS_EXPORT int operator < (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
    friend CAW_OS_EXPORT int operator > (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
    friend CAW_OS_EXPORT int operator <= (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
    friend CAW_OS_EXPORT int operator >= (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
    friend CAW_OS_EXPORT int operator == (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);
    friend CAW_OS_EXPORT int operator != (const CAWTimeValue &aLeft, const CAWTimeValue &aRight);

    static CAWTimeValue GetTimeOfDay();
    static const CAWTimeValue s_tvZero();
    static const CAWTimeValue s_tvMax();

private:
    void Normalize();

    long m_lSec;
    long m_lUsec;
};

#endif // !CAWTIMEVALUE_H

