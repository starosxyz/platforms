/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWUTILCLASSES_H
#define CAWUTILCLASSES_H

#include "starbase/CAWStdCpp.h"
#include "starbase/CAWDefines.h"
#include "starbase/CAWThreadInterface.h"

class CAWMutexThreadRecursive;
class CAWThread;

class CAW_OS_EXPORT CAWEnsureSingleThread
{
public:
    CAWEnsureSingleThread();
    void EnsureSingleThread() const;
    void Reset2CurrentThreadId();
    void Reset2ThreadId(CAW_THREAD_ID aTid);

protected:
    CAW_THREAD_ID m_ThreadIdOpen;
};

class CAW_OS_EXPORT CAWStopFlag
{
public:
    CAWStopFlag() : m_bStoppedFlag(TRUE)
    {
    }

    void SetStartFlag();

    void SetStopFlag();

    BOOL IsFlagStopped() const
    {
        m_Est.EnsureSingleThread();
        return m_bStoppedFlag;
    }

    CAWEnsureSingleThread m_Est;
    BOOL m_bStoppedFlag;
};

class CAW_OS_EXPORT CAWSignalStop : public IAWEvent
{
public:
    static CAWSignalStop* Instance();

    virtual ~CAWSignalStop();

    // Do the stop work.
    CAWResult Launch(int aSig);

    // interface IAWEvent.
    virtual CAWResult OnEventFire();

    virtual void OnDestorySelf();

private:
    CAWSignalStop();

    static CAWSignalStop s_SignalStopSingleton;
    CAWThread *m_pThread;
};

class CAW_OS_EXPORT CAWErrnoGuard
{
public:
    CAWErrnoGuard() : m_nErr(errno)
    {
    }

    ~CAWErrnoGuard()
    {
        errno = m_nErr;
    }
private:
    int m_nErr;
};

class CAW_OS_EXPORT CAWCleanUpBase
{
public:
    static void CleanupAll();

protected:
    CAWCleanUpBase();
    virtual ~CAWCleanUpBase();
    virtual void CleanUp();

private:
    CAWCleanUpBase *m_pNext;
    static CAWCleanUpBase *s_pHeader;

private:
    typedef CAWMutexThreadRecursive MutexType;

    // = Prevent assignment and initialization.
    void operator = (const CAWCleanUpBase&);
    CAWCleanUpBase(const CAWCleanUpBase&);
};

class CAW_OS_EXPORT CAWDataBlockNoMalloc
{
public:
    CAWDataBlockNoMalloc(LPCSTR aStr, size_t aLen);

    /// Read and advance <aCount> bytes, 
    CAWResult Read(LPVOID aDst, size_t aCount, size_t *aBytesRead = NULL);

    /// Write and advance <aCount> bytes
    CAWResult Write(LPCVOID aSrc, size_t aCount, size_t *aBytesWritten = NULL);
private:
    LPCSTR m_pBegin;
    LPCSTR m_pEnd;
    LPCSTR m_pCurrentRead;
    LPSTR m_pCurrentWrite;
};

#endif // !CAWUTILCLASSES_H

