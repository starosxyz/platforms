#ifndef _CAW_VOS_H_
#define _CAW_VOS_H_
#include "starbase/CAWDefines.h"
#include "starbase/CAWError.h"
#include "starbase/CAWString.h"
CAW_OS_EXPORT bool VOS_KillProcess(CAW_PID pid);
CAW_OS_EXPORT CAW_PID VOS_GetCurProcessID();
CAW_OS_EXPORT CAWResult VOS_CreateProcess(const char *pFilename, CAW_PID &pid);
CAW_OS_EXPORT void VOS_Sleep(long msec);
CAW_OS_EXPORT CAWString VOS_GetEnv(const CAWString &strkey);
CAW_OS_EXPORT CAWResult VOS_SetEnv(const CAWString &strkey, const CAWString &strvalue);
CAW_OS_EXPORT bool CheckProcessIsRunning(const CAWString &processname);
CAW_OS_EXPORT CAWResult VOS_SetLDLibraryPath(const CAWString &libpath);

CAW_OS_EXPORT long VOS_GetTickCount();

CAW_OS_EXPORT CAWString VOS_GetRealPath(const CAWString &path);


#endif /* end of _XOS_VOS_H_ */



