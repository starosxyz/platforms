#ifndef CAW_TYPEDEFS_H_
#define CAW_TYPEDEFS_H_

// Processor architecture detection.  For more info on what's defined, see:
//   http://msdn.microsoft.com/en-us/library/b0084kay.aspx
//   http://www.agner.org/optimize/calling_conventions.pdf
//   or with gcc, run: "echo | gcc -E -dM -"
#if defined(_M_X64) || defined(__x86_64__)
#define CAW_ARCH_X86_FAMILY
#define CAW_ARCH_X86_64
#define CAW_ARCH_64_BITS
#elif defined(__aarch64__)
#define CAW_ARCH_ARM_FAMILY
#define CAW_ARCH_64_BITS
#elif defined(_M_IX86) || defined(__i386__)
#define CAW_ARCH_X86_FAMILY
#define CAW_ARCH_X86
#define CAW_ARCH_32_BITS
#elif defined(__ARMEL__)
#define CAW_ARCH_ARM_FAMILY
#define CAW_ARCH_32_BITS
#elif defined(__MIPSEL__)
#if defined(__LP64__)
#define CAW_ARCH_MIPS64_FAMILY
#define CAW_ARCH_64_BITS
#else
#define CAW_ARCH_32_BITS
#define CAW_ARCH_MIPS_FAMILY
#endif
#define CAW_ARCH_32_BITS
#elif defined(__pnacl__)
#define CAW_ARCH_32_BITS
#elif defined(__PPC)
#define CAW_ARCH_32_BITS
#else
#error Please add support for your architecture in CAWTypedef.h
#endif


#endif  // CAW_TYPEDEFS_H_