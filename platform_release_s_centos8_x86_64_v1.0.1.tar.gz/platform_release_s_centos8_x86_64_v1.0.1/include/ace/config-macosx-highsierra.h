#ifndef ACE_CONFIG_MACOSX_HIGHSIERRA_H
#define ACE_CONFIG_MACOSX_HIGHSIERRA_H

#include "ace/config-macosx-sierra.h"

#endif // ACE_CONFIG_MACOSX_HIGHSIERRA_H
