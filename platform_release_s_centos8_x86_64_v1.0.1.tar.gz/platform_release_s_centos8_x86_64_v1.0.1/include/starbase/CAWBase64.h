/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWBASE64_H
#define CAWBASE64_H
#include "starbase/CAWStdCpp.h"
#include "starbase/CAWDefines.h"
#include "starbase/CAWError.h"
#include "starbase/CAWDebug.h"
#include "starbase/CAWReferenceControl.h"
#include "starbase/CAWMutex.h"
#include "starbase/CAWThreadManager.h"
#include "starbase/CAWThread.h"
#include "starbase/CAWUtilClasses.h"
#include "starbase/CAWTimeValue.h"

CAW_OS_EXPORT const char* CAW_strcaserstr(
    const char *big, 
    const char *little);

CAW_OS_EXPORT void CAW_Base64Decode(
    const char *bufcoded, 
    CAWString &strDest);

CAW_OS_EXPORT void CAW_Base64Encode(
    const unsigned char *bufin, 
    size_t nbytes, 
    CAWString &strDest);


#endif // !CAWBASE64_H

