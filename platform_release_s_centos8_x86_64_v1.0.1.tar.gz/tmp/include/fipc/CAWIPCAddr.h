/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/

#ifndef CAWIPCADDR_H
#define CAWIPCADDR_H
#include "wface/CAWACEWrapper.h"

#include "starbase/CAWStdCpp.h"
#include "starbase/CAWDefines.h"
#ifndef CAW_WIN32
#include <sys/un.h>
#else
#include <afunix.h>
#endif
class CAW_OS_EXPORT CAWIPCAddr  
{
public:
    CAWIPCAddr();
	~CAWIPCAddr();
    CAWIPCAddr(const CAWString& strpath);
    CAWIPCAddr(const CAWIPCAddr &ipaddr)
    {
        (*this)=ipaddr;
    }
    CAWIPCAddr& operator=(const CAWIPCAddr& right)
    {
        ::memcpy(&m_SockAddr,&right.m_SockAddr, sizeof(m_SockAddr));
        return (*this);  
    }

    bool operator == (const CAWIPCAddr &aRight) const;

    CAWString GetPath() const;

    DWORD GetSize() const { return sizeof (sockaddr_un); }

    const sockaddr_in* GetPtr() const 
    { 
        return (sockaddr_in*)&m_SockAddr; 
    }
    void Unlink();
private:
    sockaddr_un m_SockAddr;

};


#endif // !CAWIPCADDR_H

