#ifndef CAW_LOG_H
#define CAW_LOG_H
#include "starbase/CAWDefines.h"
#include <stdarg.h>	/* va_list */

typedef enum {
	CAWLOG_LEVEL_QUIET,
	CAWLOG_LEVEL_FATAL,
	CAWLOG_LEVEL_ERROR,
	CAWLOG_LEVEL_INFO,
	CAWLOG_LEVEL_VERBOSE,
	CAWLOG_LEVEL_DEBUG1,
	CAWLOG_LEVEL_DEBUG2,
	CAWLOG_LEVEL_DEBUG3,
	CAWLOG_LEVEL_NOT_SET = -1
} CAWLogLevel;

CAW_OS_EXPORT void     log_init(char *, CAWLogLevel, int);
CAW_OS_EXPORT int      log_change_level(CAWLogLevel);
CAW_OS_EXPORT int      log_is_on_stderr(void);
CAW_OS_EXPORT void     log_redirect_stderr_to(const char *);
CAW_OS_EXPORT CAWLogLevel get_log_level(void);
CAW_OS_EXPORT CAWLogLevel	log_level_number(char *);
CAW_OS_EXPORT const char *	log_level_name(CAWLogLevel);

CAW_OS_EXPORT void     fatal(const char *, ...);
CAW_OS_EXPORT void     error(const char *, ...);
CAW_OS_EXPORT void     logit(const char *, ...);
CAW_OS_EXPORT void     verbose(const char *, ...);
CAW_OS_EXPORT void     debug(const char *, ...);
CAW_OS_EXPORT void     debug2(const char *, ...);
CAW_OS_EXPORT void     debug3(const char *, ...);

#endif
