/**********************************************************************************
 * Copyright (C) 2013-2015, Nanjing WFNEX Technology Co., Ltd. All rights reserved.
***********************************************************************************/
#ifndef CAWERRORNETWORK_H
#define CAWERRORNETWORK_H

#include "starbase/CAWError.h"

enum {
    CAW_ERROR_NETWORK_SOCKET_ERROR = CAW_ERROR_MODULE_NETWORK + 1, 
    CAW_ERROR_NETWORK_SOCKET_RESET,
    CAW_ERROR_NETWORK_SOCKET_CLOSE,
    CAW_ERROR_NETWORK_SOCKET_BIND_ERROR,
    CAW_ERROR_NETWORK_CONNECT_ERROR,
    CAW_ERROR_NETWORK_CONNECT_TIMEOUT,
    CAW_ERROR_NETWORK_DNS_FAILURE,
    CAW_ERROR_NETWORK_PROXY_SERVER_UNAVAILABLE,
    CAW_ERROR_NETWORK_UNKNOWN_ERROR,

    ///////////For Connection Service/////////////
    CAW_ERROR_NETWORK_CONNECTION_RECONNECT, 
    CAW_ERROR_NETWORK_CONNECTION_RECONNECT_FAILED, 
    CAW_ERROR_NETWORK_CONNECTION_WRONG_TYPE, 
};


#define CAW_OPT_TRANSPORT_BASE			100

//Param. is Pointer to DWORD
//IO Read len
#define CAW_OPT_TRANSPORT_FIO_NREAD		(CAW_OPT_TRANSPORT_BASE+1)

//Param. is Pointer to DWORD
//Transport unread len
#define CAW_OPT_TRANSPORT_TRAN_NREAD		(CAW_OPT_TRANSPORT_BASE+2)

//Param. is Pointer to CAW_HANDLE
//Get fd
#define CAW_OPT_TRANSPORT_FD				(CAW_OPT_TRANSPORT_BASE+3)

//Param. is Pointer to CInetAddr
//Get address socket binded
#define CAW_OPT_TRANSPORT_LOCAL_ADDR		(CAW_OPT_TRANSPORT_BASE+4)

//Param. is Pointer to CInetAddr
//Get peer addr
#define CAW_OPT_TRANSPORT_PEER_ADDR		(CAW_OPT_TRANSPORT_BASE+5)

//If the socket is still alive
//Param. is Pointer to BOOL
#define CAW_OPT_TRANSPORT_SOCK_ALIVE		(CAW_OPT_TRANSPORT_BASE+6)

//Param. is Pointer to DWORD
//TYPE_TCP, TYPE_UDP, TYPE_SSL...
#define CAW_OPT_TRANSPORT_TRAN_TYPE 		(CAW_OPT_TRANSPORT_BASE+7)

// budingc add to support SO_KEEPALIVE function
//Param. is Pointer to DWORD
#define CAW_OPT_TRANSPORT_TCP_KEEPALIVE	(CAW_OPT_TRANSPORT_BASE+8)

//Param. is Pointer to DWORD
#define CAW_OPT_TRANSPORT_RCV_BUF_LEN	(CAW_OPT_TRANSPORT_BASE+9)

//Param. is Pointer to DWORD
#define CAW_OPT_TRANSPORT_SND_BUF_LEN 	(CAW_OPT_TRANSPORT_BASE+10)

//Param. is Pointer to CAWMessageBlock*, 
//send some user data in the connect request
#define CAW_OPT_CONNECTION_CONNCET_DATA 	(CAW_OPT_TRANSPORT_BASE+11)

//Param. is Pointer to IAWTransport** ,
//get lower transport, for class CAWTransportThreadProxy
#define CAW_OPT_LOWER_TRANSPORT	 		(CAW_OPT_TRANSPORT_BASE+12)

//Param. is Pointer to int ,
//for DSCP setting, Type of Service (TOS) settings.
#define CAW_OPT_TRANSPORT_TOS	 		(CAW_OPT_TRANSPORT_BASE+13)

///////////For Connection Service/////////////
//Param. is Pointer to BOOL
#define CS_OPT_NEED_KEEPALIVE			(CAW_OPT_TRANSPORT_BASE+31)

//Param. is Pointer to DWORD
#define CS_OPT_MAX_SENDBUF_LEN			(CAW_OPT_TRANSPORT_BASE+32)

//Param. is Pointer to BOOL
#define CS_OPT_PKG_NEED_BUF				(CAW_OPT_TRANSPORT_BASE+33)

//Param. is Pointer to DWORD (Seconds)
#define CS_OPT_KEEPALIVE_INTERVAL		(CAW_OPT_TRANSPORT_BASE+34)
//Param. is Pointer to BOOL 
#define CS_OPT_DISABLE_RCVDATA_FLAG		(CAW_OPT_TRANSPORT_BASE+35)
//////////////////////////////////////////////

/// for channel
#define CAW_OPT_CHANNEL_BASE				200

//Param. is Pointer to BOOL
#define CAW_OPT_CHANNEL_FILE_SYNC		(CAW_OPT_CHANNEL_BASE + 101)

//Param. is Pointer to BOOL
#define CAW_OPT_CHANNEL_HTTP_HEADER_NO_CONTENT_LENGTH	(CAW_OPT_CHANNEL_BASE + 111)

//Param. is Pointer to BOOL
#define CAW_OPT_CHANNEL_HTTP_PARSER_SKIP_CONTENT_LENGTH	(CAW_OPT_CHANNEL_BASE + 112)

#endif // CAWERRORNETWORK_H